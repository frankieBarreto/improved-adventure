let topSongs = [
	'First Time Ever I Saw Your Face',
	'God Only Knows',
	'A Day In The Life',
	'Life On Mars'
];

// To add to the end of an array:
topSongs.push('Fortunate Son');
topSongs.push('Landslide');
topSongs.push(12324166);

// To remove the last item
topSongs.pop(); //12324166
