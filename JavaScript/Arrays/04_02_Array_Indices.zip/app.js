let colors = [ 'red', 'orange', 'yellow', 'green', 'blue', 'indigo', 'violet' ];

// Arrays have a length
colors.length; //7

//Access elements using index:
colors[0]; //'red'

colors[6]; //'violet'

colors[7]; //undefined
