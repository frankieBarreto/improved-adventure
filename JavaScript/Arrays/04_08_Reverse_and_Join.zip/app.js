let letters = [ 'T', 'C', 'E', 'P', 'S', 'E', 'R' ];

//Remember that reverse() mutates the original array.
//It reverses IN PLACE rather than making a copy
let song = letters.reverse().join('.');
//"R.E.S.P.E.C.T"
